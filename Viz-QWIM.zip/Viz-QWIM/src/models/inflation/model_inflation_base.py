r"""Abstract base class for QWIM inflation models.

========================================================

Provides :class:`Inflation_Model_Base`, an abstract base class that
defines the common interface for all inflation models used in the QWIM
retirement-planning and actuarial pipeline.

Concrete subclasses implement two primary responsibilities:

1. **Fitting** — estimate (or accept) the model parameters from
   historical consumer-price-index data.
2. **Prediction** — produce a time-series of projected annual
   inflation rates as a :class:`polars.DataFrame`.

Design goals
------------
* **Consistency** — all models share the same ``fit`` / ``predict``
  interface so they are interchangeable downstream.
* **Safety** — thorough input validation with early returns and
  descriptive exceptions before any arithmetic.
* **Auditability** — every state transition is written to the
  project _logger in ``%s`` format (no f-strings in log calls).

Author
------
QWIM Team

Version
-------
1.0.0 (2026-07-01)
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import cast

import attrs

import numpy as np
import polars as pl

from aenum import Enum

from src.utils.custom_exceptions_errors_loggers.exception_custom import (
    Exception_Calculation,
    Exception_Validation_Input,
)
from src.utils.custom_exceptions_errors_loggers.logger_custom import get_logger


_logger = get_logger(name = __name__)


# ======================================================================
# Enums
# ======================================================================


class Inflation_Model_Status(Enum):  # noqa: N801
    """Lifecycle status of an inflation model instance.

    Attributes
    ----------
    NOT_FITTED : str
        Model has been constructed but ``fit()`` has not been called.
    FITTED : str
        Model has been successfully fitted to data.
    FAILED : str
        The most recent ``fit()`` or ``predict()`` call raised an error.
    """

    NOT_FITTED = "Not Fitted"
    FITTED = "Fitted"
    FAILED = "Failed"


def _get_inflation_model_status(
    *, name_status: str) -> Inflation_Model_Status:
    """Return a typed inflation-model status member from the dynamic ``aenum`` class."""
    return cast(Inflation_Model_Status, getattr(Inflation_Model_Status, name_status))


INFLATION_MODEL_STATUS_NOT_FITTED = _get_inflation_model_status(name_status = "NOT_FITTED")
INFLATION_MODEL_STATUS_FITTED = _get_inflation_model_status(name_status = "FITTED")
INFLATION_MODEL_STATUS_FAILED = _get_inflation_model_status(name_status = "FAILED")


# ======================================================================
# Abstract base class
# ======================================================================


@attrs.define(kw_only=True)
class Inflation_Model_Base(ABC):  # noqa: N801
    r"""Abstract base class for QWIM inflation models.

    All concrete inflation models must inherit from this class and
    implement the abstract methods :meth:`fit` and :meth:`predict`.

    Parameters
    ----------
    name_model : str, optional
        Human-readable label for the model (default ``"Inflation Model"``).

    Notes
    -----
    Members follow the project convention of ``m_`` prefix for instance
    attributes that back public properties.

    Examples
    --------
    Subclasses override ``fit`` and ``predict``:

    .. code-block:: python

        class My_Inflation_Model(Inflation_Model_Base):
            def fit(self, data):
                # estimate parameters
                self.m_status = Inflation_Model_Status.FITTED
                return self

            def predict(self, *, n_periods, start_date):
                # produce forecast DataFrame
                ...
    """

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    name_model: str = attrs.field(default="Inflation Model")
    m_status: Inflation_Model_Status = attrs.field(default=INFLATION_MODEL_STATUS_NOT_FITTED)
    m_parameters: dict[str, float] = attrs.field(factory=dict)

    def __attrs_post_init__(self) -> None:
        """Validate and initialize after attrs construction."""
        if not isinstance(self.name_model, str) or not self.name_model.strip():
            raise Exception_Validation_Input(
                "name_model must be a non-empty string",
                field_name="name_model",
                expected_type=str,
                actual_value=self.name_model,
            )

        self.name_model = self.name_model.strip()

        _logger.info(
            "Inflation_Model_Base created: '%s'",
            self.name_model,
        )

    # ------------------------------------------------------------------
    # Abstract methods
    # ------------------------------------------------------------------

    @abstractmethod
    def fit(self, *, data: pl.DataFrame) -> Inflation_Model_Base:
        """Fit (calibrate) the model to historical inflation data.

        Concrete subclasses must:

        1. Validate the incoming ``data`` DataFrame.
        2. Estimate model-specific parameters.
        3. Set ``self.m_status = Inflation_Model_Status.FITTED``.
        4. Return ``self`` for method chaining.

        Parameters
        ----------
        data : pl.DataFrame
            Historical data. Must contain at minimum a ``"Date"``
            column (:class:`polars.Date`) and an
            ``"inflation_rate"`` column (:class:`polars.Float64`)
            expressed as annual rates in decimal form
            (e.g. ``0.025`` for 2.5 %).

        Returns
        -------
        Inflation_Model_Base
            The fitted model instance (``self``).

        Raises
        ------
        Exception_Validation_Input
            If ``data`` is missing required columns or has invalid values.
        """

    @abstractmethod
    def predict(
        self, *, n_periods: int, start_date: str | None = None, freq: str = "1mo") -> pl.DataFrame:
        """Generate a forward projection of inflation rates.

        Concrete subclasses must:

        1. Verify the model is fitted (``self.m_status == FITTED``).
        2. Produce one projected inflation rate per period.
        3. Return a tidy :class:`polars.DataFrame`.

        Parameters
        ----------
        n_periods : int
            Number of periods to project (must be >= 1).
        start_date : str or None, optional
            ISO-8601 start date of the projection window
            (e.g. ``"2025-01-01"``).  If ``None``, defaults to
            ``"2025-01-01"``.
        freq : str, optional
            Polars duration string for the period step
            (default ``"1mo"`` for monthly).

        Returns
        -------
        pl.DataFrame
            DataFrame with columns:

            * ``"Date"`` — :class:`polars.Date`
            * ``"inflation_rate"`` — :class:`polars.Float64`, decimal form

        Raises
        ------
        Exception_Calculation
            If the model has not been fitted yet.
        Exception_Validation_Input
            If ``n_periods`` is not a positive integer.
        """

    @abstractmethod
    def get_annual_rate(self) -> float:
        """Return a scalar representative annual inflation rate.

        For deterministic models this is the fixed rate; for
        stochastic models this is typically the long-run mean.

        Returns
        -------
        float
            Annual inflation rate in decimal form (e.g. ``0.025``).

        Raises
        ------
        Exception_Calculation
            If the model has not been fitted yet.
        """

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def status(self) -> Inflation_Model_Status:
        """Inflation_Model_Status : Current lifecycle status."""
        return self.m_status

    @property
    def is_fitted(self) -> bool:
        """Bool : ``True`` iff the model has been fitted successfully."""
        return self.m_status == INFLATION_MODEL_STATUS_FITTED

    @property
    def parameters(self) -> dict[str, float]:
        """dict[str, float] : Model parameters (copy)."""
        return self.m_parameters.copy()

    # ------------------------------------------------------------------
    # Shared validation helpers
    # ------------------------------------------------------------------

    def _validate_n_periods(self, *, n_periods: int) -> None:
        """Validate that *n_periods* is a positive integer.

        Parameters
        ----------
        n_periods : int
            Number of projection periods to validate.

        Raises
        ------
        Exception_Validation_Input
            If ``n_periods`` is boolean, is not an ``int``, or is less
            than 1.
        """
        if isinstance(n_periods, bool) or not isinstance(n_periods, int) or n_periods < 1:
            raise Exception_Validation_Input(
                "n_periods must be a positive integer (>= 1)",
                field_name="n_periods",
                expected_type=int,
                actual_value=n_periods,
            )

    def _validate_inflation_data(self, *, data: pl.DataFrame) -> None:
        """Validate structure and content of historical inflation data.

        Parameters
        ----------
        data : pl.DataFrame
            Input DataFrame to validate.

        Raises
        ------
        Exception_Validation_Input
            If ``data`` is not a :class:`polars.DataFrame`, is empty,
            or is missing required columns (``"Date"``,
            ``"inflation_rate"``).
        """
        if not isinstance(data, pl.DataFrame):
            raise Exception_Validation_Input(
                "data must be a polars.DataFrame",
                field_name="data",
                expected_type=pl.DataFrame,
                actual_value=type(data).__name__,
            )

        if len(data) == 0:
            raise Exception_Validation_Input(
                "data must not be empty",
                field_name="data",
                expected_type=pl.DataFrame,
                actual_value="empty DataFrame",
            )

        required_cols = {"Date", "inflation_rate"}
        missing = required_cols - set(data.columns)
        if missing:
            raise Exception_Validation_Input(
                f"data is missing required columns: {sorted(missing)}",
                field_name="data",
                expected_type=pl.DataFrame,
                actual_value=data.columns,
            )

    def _check_is_fitted(self) -> None:
        """Assert the model has been fitted.

        Raises
        ------
        Exception_Calculation
            If :attr:`is_fitted` is ``False``.
        """
        if not self.is_fitted:
            raise Exception_Calculation(
                f"Model '{self.name_model}' has not been fitted — call fit() first",
            )

    # ------------------------------------------------------------------
    # Shared utility methods
    # ------------------------------------------------------------------

    def get_summary_statistics(self, *, df_predict: pl.DataFrame) -> pl.DataFrame:
        """Compute basic summary statistics over a prediction DataFrame.

        Parameters
        ----------
        df_predict : pl.DataFrame
            Output of :meth:`predict` with an ``"inflation_rate"`` column.

        Returns
        -------
        pl.DataFrame
            Single-row DataFrame with columns ``"Mean"``, ``"Median"``,
            ``"Std"``, ``"Min"``, ``"Max"``, ``"P5"``, ``"P95"``.

        Raises
        ------
        Exception_Validation_Input
            If ``df_predict`` lacks an ``"inflation_rate"`` column.
        """
        if "inflation_rate" not in df_predict.columns:
            raise Exception_Validation_Input(
                "df_predict must contain an 'inflation_rate' column",
                field_name="df_predict",
                expected_type=pl.DataFrame,
                actual_value=df_predict.columns,
            )

        rates = df_predict["inflation_rate"].to_numpy()

        return pl.DataFrame(
            {
                "Mean": [float(np.mean(rates))],
                "Median": [float(np.median(rates))],
                "Std": [float(np.std(rates, ddof=1)) if len(rates) > 1 else 0.0],
                "Min": [float(np.min(rates))],
                "Max": [float(np.max(rates))],
                "P5": [float(np.percentile(rates, 5))],
                "P95": [float(np.percentile(rates, 95))],
            },
        )

    # ------------------------------------------------------------------
    # Dunder overrides
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        """Return a string representation of this instance."""
        return f"Inflation_Model_Base(name='{self.name_model}', status={self.m_status.value})"
